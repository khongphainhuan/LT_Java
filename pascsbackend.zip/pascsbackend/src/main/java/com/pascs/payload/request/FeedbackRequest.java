package com.pascs.payload.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FeedbackRequest {
    private Long serviceId;

    @NotNull
    @Min(1)
    @Max(5)
    private Integer rating;

    private String comment;

    // Explicit getters for compilation
    public Long getServiceId() { return serviceId; }
    public Integer getRating() { return rating; }
    public String getComment() { return comment; }
}