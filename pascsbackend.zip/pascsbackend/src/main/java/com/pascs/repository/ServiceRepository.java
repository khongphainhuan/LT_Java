package com.pascs.repository;

import com.pascs.model.Service;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ServiceRepository extends JpaRepository<Service, Long> {
    Optional<Service> findByCode(String code);
    List<Service> findByStatus(Service.ServiceStatus status);
    boolean existsByCode(String code);
    
    @Query("SELECT COUNT(s) FROM Service s WHERE s.status = ?1")
    long countByStatus(Service.ServiceStatus status);
}   